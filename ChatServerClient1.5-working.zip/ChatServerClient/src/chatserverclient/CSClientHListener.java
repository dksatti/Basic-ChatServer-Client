package chatserverclient;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CSClientHListener implements ActionListener{
	
	
	private UIHomeInit uih = new UIHomeInit();
	private ClientThread cT = new ClientThread();
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		System.out.println("event ");
		if (e.getSource()== uih.bLogin){
			System.out.println("in send listener");
			actionListenerLogin();
		}
	
		
		if (e.getSource() == uih.bExit){
			actionListenerExit();
		}
	}

	private void actionListenerExit() {
		// TODO Auto-generated method stub
		uih.closeUIH();
	}

	private void actionListenerLogin() {
		cT.ConnFrom = uih.login;
		cT.processPassword();
	}


}
