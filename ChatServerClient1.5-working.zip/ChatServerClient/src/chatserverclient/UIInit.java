package chatserverclient;

import java.awt.*;
import java.net.Socket;
import java.util.logging.Logger;

import javax.swing.*;

public class UIInit {

	public static JFrame frame;
	public static JButton bSend, bExit;
	public static JTextArea tMessage1, tMessage2;
	public static JLabel lUser1,lUser2;
	public static Insets is;
	private static CSClientListener cscl;
	public static JScrollPane jsTA1, jsTA2;
	public static String[] users;
	
	
	public void createUI(){
		frame = new JFrame("Chat Window");
		Container c = frame.getContentPane();
		frame.setLayout(null);
		frame.setSize(400, 800);
		layElements (c);
		frame.setVisible(true);
			
	}
	public void layElements(Container panel){
		
		
		is = panel.getInsets();
		bSend = new JButton("Send");
		bExit = new JButton("Exit");
		tMessage1 = new JTextArea();
		tMessage2 = new JTextArea();
				
		tMessage1.setEditable(true); 
		tMessage1.setLineWrap(true);
		tMessage1.setWrapStyleWord(true);
				
		jsTA1 = new JScrollPane(tMessage1);
		jsTA1.setBounds(is.left + 25, is.top +25,300,150);
		
		tMessage2.setEditable(false); 
		tMessage2.setLineWrap(true);
		tMessage2.setWrapStyleWord(true);
		
		lUser1 = new JLabel("");
		lUser2 = new JLabel("");
		
		cscl = new CSClientListener();
		
		bSend.addActionListener(cscl);
		bExit.addActionListener(cscl);
		
		
		jsTA2 = new JScrollPane(tMessage2);
		jsTA2.setBounds(is.left + 25, is.top + 200,300,150);
				
		bSend.setBounds(is.left + 25, is.top + 375, 100, 25);
		bExit.setBounds(is.left + 200, is.top + 375, 100, 25);
		
		lUser1.setBounds(is.left + 25, is.top+500,100,25);
		lUser2.setBounds(is.left + 25, is.top+525,100,25);
		
		panel.add(bSend);
		panel.add(bExit);
		panel.add(jsTA1);
		panel.add(jsTA2);
		panel.add(lUser1);
		panel.add(lUser2);
		
		
	}
	public String getMessage() {
		// TODO Auto-generated method stub
		
		System.out.println("In getMesssage()");
		return tMessage1.getText(); 
		
	}
	
	public void closeUI() {
		// TODO Auto-generated method stub
		System.exit(0);
	}
	
	public void listUsers(String[] users) {
		// TODO Auto-generated method stub
		
		lUser1.setText(users[0]);
		lUser2.setText(users[1]);
		return;
		
	}
}
