package chatserverclient;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CSClientListener implements ActionListener{
	
	
	private UIInit ui= new UIInit();
	private ClientThread cT = new ClientThread();
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		System.out.println("event ");
		if (e.getSource()== ui.bSend){
			System.out.println("in send listener");
			actionListenerSend();
		}
	
		
		if (e.getSource() == ui.bExit){
			actionListenerExit();
		}
		
		if (e.getSource() == ui.lUser1){
				actionListenerConnectToUser(ui.users[0]);
		}		
		
		if (e.getSource() == ui.lUser2){
			actionListenerConnectToUser(ui.users[1]);
	}	
	}

	private void actionListenerConnectToUser(String user) {
		// TODO Auto-generated method stub
		cT.connectToUser(user);
	}

	private void actionListenerExit() {
		// TODO Auto-generated method stub
		cT.closeConnection();
	}

	private void actionListenerSend() {
		
		cT.processMessages();
	}


}
