package chatserverclient;

import java.awt.*;

import javax.swing.*;

public class UIHomeInit {

	public static JFrame frame;
	public static JButton bLogin, bExit;
	public static JPasswordField tPassword;
	public static JLabel lLogin,lPassword, lStatus;
	public static JTextField tLogin;
	public static Insets is;
	public static String login,password;
	public static char[] pwd;
	
	
	public void createHUI(){
		frame = new JFrame("Chat Login");
		Container c = frame.getContentPane();
		frame.setLayout(null);
		frame.setSize(400, 600);
		layHElements (c);
		frame.setVisible(true);
			
	}
	public void layHElements(Container panel){
		is = panel.getInsets();
		bLogin = new JButton("Login");
		bExit = new JButton("Exit");
		lLogin = new JLabel("Login");
		lPassword = new JLabel("Password");
		lStatus = new JLabel("Status");
		tLogin = new JTextField();
		tPassword = new JPasswordField();
		
		
		CSClientHListener cschl = new CSClientHListener();
		
		bLogin.addActionListener(cschl);
		bExit.addActionListener(cschl);
		
		
		lLogin.setBounds(is.left+25,is.top+50, 100,25);
		lPassword.setBounds(is.left + 25, is.top+100, 100,25);
		lStatus.setBounds(is.left + 25, is.top+425,100,25);
		
		
		tLogin.setBounds(is.left+150, is.top+50, 100,25);
		tPassword.setBounds(is.left + 150, is.top+100,100,25 );
				
		bLogin.setBounds(is.left + 25, is.top + 375, 100, 25);
		bExit.setBounds(is.left + 200, is.top + 375, 100, 25);
		
		lStatus.setBounds(is.left+25, is.top +400 , 100, 25);
		
		panel.add(bLogin);
		panel.add(bExit);
		panel.add(lLogin);
		panel.add(lPassword);
		panel.add(lStatus);
		panel.add(tLogin);
		panel.add(tPassword);
	}
	public String getPassword() {
		// TODO Auto-generated method stub
		String passwdString;
		
		System.out.println("In getMesssage()");
		login =tLogin.getText();
		pwd = tPassword.getPassword();
		password = String.valueOf(pwd);
		System.out.println("Password is:" + password);
		passwdString = login + "/" + password;
		return passwdString; 
	}
	
	public void closeUIH() {
		// TODO Auto-generated method stub
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.dispose();
		//System.exit(0);
	}
	public void writeStatus(String failedLoginMsg) {
		// TODO Auto-generated method stub
		
		lStatus.setText(failedLoginMsg);		
		return;
		
	}
	
}
