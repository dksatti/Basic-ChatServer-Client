package chatserver;

import java.net.*;
import java.io.*;
import java.sql.SQLException;
import java.lang.ProcessBuilder;

public class ServerProc extends Process{
	public static Socket sock;
	public static DataInputStream disP;
	public static DataOutputStream dosP;
        private static String ipStrP;
        public static InputStream iS;
        public static OutputStream oS;
	//public static ErrorStream eS;
        
	public static void run_main(){

				try {
               		
               		disP = new DataInputStream (sock.getInputStream());
               		dosP = new DataOutputStream (sock.getOutputStream());
                    	
               
               	while (true) {

				ipStrP = disP.readUTF();
				System.out.println("String is " + ipStrP);

				if (ipStrP.equals("exit")) {
					sock.close();
					dosP.close();
					disP.close();
					break;
				} else if (ipStrP.startsWith("Chat/")) {
                    dosP.writeUTF("Hello world \n");
				}
			}/* End of while() */
								
                    } catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
                    } 
            }
        private static ServerProc ServerProc() {
		// TODO Auto-generated method stub
		return null;
	}
		public void destroy()
        {
            System.exit(0);
        }
        public int exitValue()
        {
            return 0;
        }
        public int waitFor()
        {
            return 0;
        }
        public InputStream getErrorStream(){
        return iS;
        }
        public InputStream getInputStream(){
        	
			return iS;
            
        }
        public OutputStream getOutputStream(){
        	
            return oS;
        }
        
    }
	