package chatserver;

import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.pool.OracleDataSource;

public class Odbc {
	
	private static final Socket ss = null;
	public static String url="jdbc:oracle:thin:@localhost:1521:xe";
	public static String login,password, pwdDB;
	public static Connection conn;
        public static Socket rcvrSock;
        private static boolean bVar;
	
	public static boolean dbCheck(String passwdInfo) throws SQLException{
		
		OracleDataSource ods = new OracleDataSource();
		ods.setURL(url);
		ods.setUser("wm910");
		ods.setPassword("wm910");
		conn = ods.getConnection();
		boolean valid = false;
		Statement stmt = null;	
		
		if (passwdInfo != null){
			System.out.println ("Splitting password info");
			String[] str = passwdInfo.split("/");
			System.out.println(str[0]+ "," + str[1]);
			login = str[0];
			password = str[1];
			System.out.println("login and password are" + login + password);
		}
		//String sql = "select PASSWORD from wm910.pwdTable where login = '" + login + "';";
		String sql = "select * from wm910.pwdTable where login = '" + login + "'";
		System.out.println("The sql is " + sql);
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		while(rs.next()){
			pwdDB = rs.getString("PASSWORD");
		}
		
		if (password.equals(pwdDB))
			valid = true;
		return (valid);
	}

	public boolean updateUserSocket(String User, Socket ss) {
		// TODO Auto-generated method stub
		
		try {
			boolean bVar = false;
			String sql = "INSERT INTO wm910.ticket " + "VALUES ('" + User + "','" + ss + "')";
			
			System.out.println(sql);
			PreparedStatement ps = conn.prepareStatement(sql);
				
				bVar = ps.execute();
		
				if (bVar = true){
					System.out.println("Record inserted into the db");
				} else {
					System.out.println("Record could not be inserted into the db");
				}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
                        
		}
		return bVar;
		
	}

	/* public String getReceivers() {
		// TODO Auto-generated method stub
		String recvrlist = null;
		String sql = "Select ConnFrom from wm910.Ticket";
		try {
			Statement s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
			String recvrs[] = null;
			int i=0;
			while (rs.next()){
				recvrs[i++] = rs.getString("ConnFrom");
			}
			recvrlist = recvrs.toString();
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return recvrlist;
	}

	public String getSenders(String connFrom) {
		// TODO Auto-generated method stub
		
		String senders[] = null,senderslist = null;
		String sql = "select ConnFrom wm910.ticket";
		Statement s;
		try {
			s = conn.createStatement();
			ResultSet rs = s.executeQuery(sql);
		
			int i = 0;
			while (rs.next()){
				senders[i++] = rs.getString("ConnFrom");
			}
			senderslist = senders.toString();
			senderslist = senderslist.replace(connFrom, " ");
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return senderslist;
	}*/
        public String getRecvr(String iPCName) {
		// TODO Auto-generated method stub
		String rSock = null;
		//String sql = "Select rcvrSock from wm910.Ticket where iPCName is iCName";
		try {
			String sql = "select rcvrSock from wm910.Ticket where iPCName = '" + iPCName + "';";
                        System.out.println("The sql is " + sql);
                        PreparedStatement ps = conn.prepareStatement(sql);
                        ResultSet rs = ps.executeQuery(sql );
                        while (rs.next()) {
                                iPCName = rs.getString("iPCName");
                                rSock = rs.getString("rcvrSock");	
                        }
             	} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return rSock;
	}

}