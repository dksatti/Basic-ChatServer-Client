		package chatserver;

		import java.io.DataInputStream;
		import java.io.DataOutputStream;
		import java.io.IOException;
		import java.sql.SQLException;
		import java.util.logging.Level;
		import java.util.logging.Logger;
		import java.net.ServerSocket;
		import java.net.Socket;


		public class Server{
			private static ServerSocket ss;
		    public static String ipStr,rcvrStr,iCompName, iLoginInfo;
			public  Socket ssNew, rcvr;
		    private static DataInputStream dis;
			private static DataOutputStream dos;
			public static Logger log;
		        
			
			
			@SuppressWarnings("resource")
			public static void main(String[] args) {
		       	// TODO Auto-generated method stub
				
				log = Logger.getLogger("ChatServer.log");
				log.setLevel(Level.INFO);
				
				Server cs = new Server();
		        Odbc odbc = new Odbc();
				try {
					ss = new ServerSocket(7000);
								
				
					while (true){
						
										
						System.out.println (" Just Entered While loop");
						cs.ssNew = ss.accept();
					
		                dis = new DataInputStream(cs.ssNew.getInputStream());
						dos = new DataOutputStream(cs.ssNew.getOutputStream());

						while (true){
							ipStr = dis.readUTF();
							System.out.println("String is " + ipStr);

						
							if (ipStr.startsWith("exit")) {
								cs.ssNew.close();
								dos.close();
								dis.close();
								break;
							} else if (ipStr.startsWith("Validate/")){	                                
								System.out.println("I am in validate password");
								System.out.println("ipstr is " + ipStr);
								cs.parseUserInfo(ipStr);
								boolean recAvailable = odbc.dbCheck(iLoginInfo);
									if (recAvailable = false) {
										dos.writeUTF("Member Not Found");
										ipStr = null;
										continue;
									} else {
										dos.writeUTF("Member Found");
										System.out.println (iCompName);
										odbc.updateUserSocket(iCompName,cs.ssNew);
										System.out.println("Valid member");
										ServerProc sP = new ServerProc();
				                        sP.sock = cs.ssNew;
				                        sP.run_main();
									}
							}
						}/* End of while() */
		            }/* End of while() */
			        }catch (SQLException se){
                        se.printStackTrace();
                }catch (IOException e){
                        e.printStackTrace();
                }
				}/* End of main() */
		    
		        public static void parseUserInfo(String ipStr) {
				// TODO Auto-generated method stub
				String[] s1,s2;
				String bigStr;
				s1 = ipStr.split("/",2);
				 bigStr = s1[1];
				
				 s2 = bigStr.split("/",2);
				 iCompName = s2[0];
				 iLoginInfo = s2[1];
				
			}
		        public static String parseRecvrInfo(String ipStr) {
				// TODO Auto-generated method stub
				String[] s1;
				s1 = ipStr.split("/");
		                return s1[1];
			}

	}

